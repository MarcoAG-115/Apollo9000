import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Asteroid2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Asteroid2 extends Actor
{
    
    /**
     * Act - do whatever the Asteroid2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       
        setLocation(getX()-1, getY());
        GreenfootImage img = getImage();
        img.scale(70, 50);
    }
    
    public boolean hitsRocket2(Rocket ship2)
    {
        return getObjectsInRange(getImage().getWidth()/2, 
            Rocket.class).contains(ship2);
    }
    
    public boolean hitsLaser2(Laser laser2)
    {
        return getObjectsInRange(getImage().getWidth()/2, 
            Laser.class).contains(laser2);
    }
}
