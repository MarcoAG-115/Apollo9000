import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Moon here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Moon extends Actor
{
    int counter = 0;
    int count = 0;
    GreenfootImage img = getImage();
    int w = 250;
    int h = 230;
    boolean check = true;
    /**
     * Act - do whatever the Moon wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       moonMovement();
    } 
    
    public void moonMovement() 
    {
       if (counter <= 300)
       {
            
                img.scale(250, 230);
                if (getX() == 500)
                {
                    setLocation(getX(), getY());
                }
                else
                {
                    setLocation(getX()-1, getY());
                }
                counter++;
       }
       else if (counter > 300) //time it takes for the Moon to show up
       {
                if (getX() == 300)
                {
                    setLocation(getX(), getY());
                }
                else
                {
                    setLocation(getX()-1, getY()+1);
                }
       }
       if (count >= 1750)
        {
            setLocation(getX(), getY() + 1);
        }
        count++;
    } 
} 
