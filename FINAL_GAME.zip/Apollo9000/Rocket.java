import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Rocket here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rocket extends Actor
{
    private int cooldown = 10;
    public static int health = 5;
    GreenfootImage img = getImage();
    int timer = 0;
    /**
     * Act - do whatever the Rocket wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        img.scale(90, 75);
        
        if (Greenfoot.mouseMoved(null)) {
            MouseInfo mouse = Greenfoot.getMouseInfo();
            setLocation(mouse.getX(), mouse.getY());
        }
        if (Greenfoot.isKeyDown("space")) {
            if (cooldown == 10) {
                shoot();
            }
            if (cooldown >= 0) {
                cooldown--;
            }
            if (cooldown == -1) {
                cooldown = 10;
            }
        }
        boss1Damage();
        boss2Damage();
        boss3Damage();
        explosionDamage();
        death();
    }
    
    public static int getHealth() 
    {
        return health;
    }
    
    public void shoot() {
        Actor laser;
        getWorld().addObject(new Laser(), getX() + 44, getY() + 20);
        getWorld().addObject(new Laser(), getX() + 44, getY() - 20);
    }
   
    
    public void explosionDamage()
    {
        Asteroid1 ast1 = (Asteroid1)getOneIntersectingObject(Asteroid1.class);
        if (ast1 != null && getNeighbours(getImage().getWidth()/2, false, 
            Asteroid1.class).contains(ast1) && ast1.hitsRocket1(this))
        {
            getWorld().addObject(new Explosion2(), getX(), getY());
            Greenfoot.playSound("DeathSound.mp3");
            removeTouching(Asteroid1.class);
            health = health - 1;
            getWorld().addObject(new Health(), 120, 50);
        }
   
        Asteroid2 ast2 = (Asteroid2)getOneIntersectingObject(Asteroid2.class);
        if (ast2 != null && getNeighbours(getImage().getWidth()/2, false, 
            Asteroid2.class).contains(ast2) && ast2.hitsRocket2(this))
        {
            getWorld().addObject(new Explosion2(), getX(), getY());
            Greenfoot.playSound("DeathSound.mp3");
            removeTouching(Asteroid2.class);
            health = health - 1;
            getWorld().addObject(new Health(), 120, 50);
        }
    
    }
    
    public void death()
    {
        if (health < 0)
        {
            
            getWorld().removeObject(this); 
            Greenfoot.setWorld(new DeathScreen());
               
        }
    }
    
    public void boss1Damage()
    {
        BossLaser laser = (BossLaser)getOneIntersectingObject(BossLaser.class);
        if (laser != null && getNeighbours(getImage().getWidth()/2, false, 
            BossLaser.class).contains(laser) && laser.hitsRocket01(this))
        {
            getWorld().addObject(new Explosion2(), getX(), getY());
            Greenfoot.playSound("DeathSound.mp3");
            removeTouching(BossLaser.class);
            health = health - 1;
            getWorld().addObject(new Health(), 120, 50);
        }
    }
    public void boss2Damage()
    {
        Boss2Laser laser2 = (Boss2Laser)getOneIntersectingObject(Boss2Laser.class);
        if (laser2 != null && getNeighbours(getImage().getWidth()/2, false, 
            Boss2Laser.class).contains(laser2) && laser2.hitsRocket02(this))
        {
            getWorld().addObject(new Explosion2(), getX(), getY());
            Greenfoot.playSound("DeathSound.mp3");
            removeTouching(Boss2Laser.class);
            health = health - 1;
            getWorld().addObject(new Health(), 120, 50);
        }
    }
    public void boss3Damage()
    {
        
        Boss3Laser laser3 = (Boss3Laser)getOneIntersectingObject(Boss3Laser.class);
        if (laser3 != null && getNeighbours(getImage().getWidth()/2, false, 
            Boss3Laser.class).contains(laser3) && laser3.hitsRocket3(this))
        {
            getWorld().addObject(new Explosion2(), getX(), getY());
            Greenfoot.playSound("DeathSound.mp3");
            removeTouching(Boss3Laser.class);
            health = health - 1;
            getWorld().addObject(new Health(), 120, 50);
        }
    }
}
