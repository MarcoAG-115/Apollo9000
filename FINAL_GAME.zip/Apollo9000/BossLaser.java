import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BossLaser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BossLaser extends Actor
{
    private boolean removed = false;
    /**
     * Act - do whatever the BossLaser wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move(-5);
    }
    public void isRemoved() {
        if (isAtEdge()) {
            getWorld().removeObject(this);
            removed = true;
        }
    }
    public void bossShoot() {
        Actor laser;
        getWorld().addObject(new BossLaser(), getX() - 50, getY());
        getWorld().addObject(new BossLaser(), getX() - 50, getY());
    }
    
    public boolean hitsRocket01(Rocket ship01)
    {
        return getObjectsInRange(getImage().getWidth()/2, 
            Rocket.class).contains(ship01);
    }
}
