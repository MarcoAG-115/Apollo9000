import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Time here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Time extends Actor
{
    /**
     * Act - do whatever the Time wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        GreenfootImage img1 = new GreenfootImage("Estimated Mission Duration in Seconds: " + (MyWorld.count)/70, 24, Color.WHITE, Color.BLACK);
        setImage(img1);
    }    
}
