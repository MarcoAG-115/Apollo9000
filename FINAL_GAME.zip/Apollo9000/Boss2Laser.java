import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Boss2Laser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boss2Laser extends Actor
{
    private boolean removed = false;
    /**
     * Act - do whatever the Boss2Laser wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        isRemoved();
        move(-5);
        
    }
    public void isRemoved() {
        if (isAtEdge()) {
            getWorld().removeObject(this);
            removed = true;
        }
    }
    
    public boolean hitsRocket02(Rocket ship02)
    {
        return getObjectsInRange(getImage().getWidth()/2, 
            Rocket.class).contains(ship02);
    }
}
