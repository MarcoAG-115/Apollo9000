import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    public static int count = 0;
    boolean check = true;
    boolean check2 = true;
    boolean check3 = true;
    boolean check4 = false;
    boolean check5 = false;
    boolean startCounter = false;
    boolean startCounter2 = false;
    int counter = 0;
    int counter2 = 0;
    private Rocket s = new Rocket();
    private Boss3 b;
    public static int time = 0;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1, false);
        addObject(s, 300, 200);
        addObject(new Earth(), 0, 400);
        addObject(new Sun(), 500, 100);
        setPaintOrder(Time.class, Health.class, GameOver.class, End.class, Rocket.class, Laser.class, 
            Boss1.class, Boss2.class, Boss3.class, FinalExplosion.class, 
            Asteroid1.class, Asteroid2.class, Explosion1.class, Explosion2.class,
            Earth.class, Moon.class, Mars.class, AsteroidBelt.class, Jupiter.class, 
            Saturn.class, Uranus.class, Neptune.class, Boss3Laser.class, 
            Mothership.class, Sun.class);
    }
    
    public void act()
    {
        
        
        asteroidSpawner();
        count++;
        moonSpawner();
        boss1Spawner();
        marsSpawner();
        beltSpawner();
        jupiterSpawner();
        boss2Spawner();
        saturnSpawner();
        uranusSpawner();
        neptuneSpawner();
        mothershipSpawner();
        boss3Spawner();
        boss3Movement();
        endExplosion();
        
        
    }
    
    public void asteroidSpawner()
    {
        if (Greenfoot.getRandomNumber(100) < 1) 
        {
            addObject(new Asteroid1(),
                590, Greenfoot.getRandomNumber(300));
            addObject(new Asteroid2(),
                590, Greenfoot.getRandomNumber(300));
        }
    }
    
    public void moonSpawner()
    {
        if (count == 450)
        {
            addObject(new Moon(), 800, 200);
        }
    }
    
    public void boss1Spawner()
    {
        if (count == 1500)
        {
            addObject(new Boss1(), 650, 200);
        }
    }
    
    public void marsSpawner()
    {
        if ((getObjects(Boss1.class).isEmpty()) && count >= 1600 && check == true)
        {
            addObject(new Mars(), 1000, 200);
            check = false;
            startCounter = true;
        }
        
        if (startCounter == true)
        {
            counter++;
        }
    }
    
    public void beltSpawner()
    {
        if (counter == 1500)
        {
            addObject(new AsteroidBelt(), 1000, 200);
        }
    }
    
    public void jupiterSpawner()
    {
        if (counter == 3000)
        {
            addObject(new Jupiter(), 1000, 200);
        }
    }
    
    public void boss2Spawner()
    {
        if (counter == 4500)
        {
            addObject(new Boss2(), 1000, 200);
        }
    }
    
    public void saturnSpawner()
    {
        if ((getObjects(Boss2.class).isEmpty()) && counter >= 4600 && check2 == true)
        {
            addObject(new Saturn(), 1000, 200);
            check2 = false;
            startCounter2 = true;
        }
        if (startCounter2 == true)
        {
            counter2++;
        }
    }
    
    public void uranusSpawner()
    {
        if (counter2 == 1500)
        {
            addObject(new Uranus(), 1000, 200);
        }
    }
    
    public void neptuneSpawner()
    {
        if (counter2 == 3000)
        {
            addObject(new Neptune(), 1000, 200);
        }
    }
    
    public void mothershipSpawner()
    {
        if (counter2 == 4500)
        {
            addObject(new Mothership(), 300, 1000);
        }
    }
    
    public void boss3Spawner()
    {
        if (counter2 == 4575)
        {
            b = new Boss3();
            addObject(b, 400, 200);
            check4 = true;
        }
    }
    
    public void boss3Movement()
    {
        if (check4 == true && counter > 4575 && !(getObjects(Boss3.class).isEmpty()))
        {
            
            b.setLocation(s.getX() + 300, s.getY());
            if (Greenfoot.getRandomNumber(500) < 1) 
            {
                addObject(new Boss3Laser(),
                    Greenfoot.getRandomNumber(500), -50);
            }
        }
    }
    
    public void timer()
    {
        if (!((getObjects(Boss3.class).isEmpty()) && counter >= 7600 && check3 == true 
            && check4 == true))
        {
            count++;
        }
    }
    
    public static int getTime() 
    {
        return time;
    }
    
    public static int getCount() 
    {
        return count;
    }
    
    public void endExplosion()
    {
        if ((getObjects(Boss3.class).isEmpty()) && counter >= 7600 && check3 == true 
            && check4 == true)
        {
            addObject(new FinalExplosion(), 300, 200);
            check3 = false;
            addObject(new End(), 300, 200);
            addObject(new Time(), 300, 300);
        }
    }
    
    
}
