import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Asteroid1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Asteroid1 extends Actor
{
    GreenfootImage img = getImage();
    /**
     * Act - do whatever the Asteroid1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        
        setLocation(getX()-2, getY());
        img.scale(50, 30);
    }   
    
    public boolean hitsRocket1(Rocket ship1)
    {
        return getObjectsInRange(getImage().getWidth()/2, 
            Rocket.class).contains(ship1);
    }
    
    public boolean hitsLaser1(Laser laser1)
    {
        return getObjectsInRange(getImage().getWidth()/2, 
            Laser.class).contains(laser1);
    }
}
