import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Boss1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boss1 extends Actor
{
    int healthB = 0;
    private int num = 1;
    /**
     * Act - do whatever the Boss1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (Greenfoot.getRandomNumber(100) < 1)
        {
            bossShoot();
        }
        boss1Movement();
        boss1Damage();
        
    }
    public void bossShoot() {
        Actor BossLaser;
        getWorld().addObject(new BossLaser(), getX(), getY() + 20);
        getWorld().addObject(new BossLaser(), getX(), getY() - 20);
    }
    public void boss1Movement() 
    {
        
        if (getX() == 500)
        {
            setLocation(getX(), getY());
        }
        else
        {
            setLocation(getX()-1, getY());
        }
        
        
    }
    public void boss1Damage() 
    {
        
        if (isTouching(Laser.class))
        {
            removeTouching(Laser.class);
            getWorld().addObject(new Explosion1(), getX(), getY());
            Greenfoot.playSound("explosion.wav");
            healthB = healthB + 1;
            if (healthB > 100) 
            {
                getWorld().removeObject(this);
            }
        }
        
        
    }
}
