import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Saturn here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Saturn extends Actor
{
    GreenfootImage img = getImage();
    /**
     * Act - do whatever the Saturn wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        img.scale(700, 400);
        setLocation(getX()-1, getY());
    }    
}
