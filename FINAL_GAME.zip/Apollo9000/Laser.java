import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Laser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Laser extends Actor
{
    /**
     * Act - do whatever the Laser wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        
        move(5);
        
        destroyAsteroids();
        
        
    }
    public void destroyAsteroids() 
    {
        Asteroid1 ast1 = (Asteroid1)getOneIntersectingObject(Asteroid1.class);
        if (isTouching(Asteroid1.class))
        {
            getWorld().removeObject(ast1);
            getWorld().addObject(new Explosion1(), getX(), getY());
            Greenfoot.playSound("explosion.wav");
        }
   
        Asteroid2 ast2 = (Asteroid2)getOneIntersectingObject(Asteroid2.class);
        if (ast2 != null && getNeighbours(getImage().getWidth()/2, false, 
            Asteroid2.class).contains(ast2) && ast2.hitsLaser2(this))
        {
            getWorld().removeObject(ast2);
            getWorld().addObject(new Explosion1(), getX(), getY());
            Greenfoot.playSound("explosion.wav");
        }
    }
    
}
