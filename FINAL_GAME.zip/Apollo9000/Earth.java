import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Earth here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Earth extends Actor
{
    private final double SCALE_FACTOR = .25;
    /**
     * Act - do whatever the Earth wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       GreenfootImage img = getImage();
       img.scale(360, 340);
       earthMovement();
       
       
    }
    public void earthMovement() 
    {
       
       if (getY() == 200)
       {
           setLocation(getX()-1, getY());
       }
       else
       {
           setLocation(getX()+1, getY()-1);
       }
       
    }
}
