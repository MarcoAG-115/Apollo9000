import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Boss3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boss3 extends Actor
{
    int healthB = 0;
    GreenfootImage img = getImage();
    /**
     * Act - do whatever the Boss3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        img.scale(400, 400);
        boss3Movement();
        boss3Damage();
    } 
    public void boss3Movement() 
    {
        
        if (getX() == 500)
        {
            setLocation(getX(), getY());
        }
        else
        {
            setLocation(getX()-1, getY());
        }
        
    }
    public void boss3Damage() 
    {
        
        if (isTouching(Laser.class))
        {
            removeTouching(Laser.class);
            getWorld().addObject(new Explosion1(), getX(), getY());
            Greenfoot.playSound("explosion.wav");
            healthB = healthB + 1;
            if (healthB > 250)
            {
                getWorld().addObject(new FinalExplosion(), getX(), getY());
                getWorld().removeObject(this);
                Greenfoot.playSound("fanfare.wav");
            }
        }
        
    }
    
    public void bossShoot() {
        Actor BossLaser;
        getWorld().addObject(new Boss3Laser(), 750, getY() + 20);
        getWorld().addObject(new Boss3Laser(), 750, getY() - 20);
    }
}
