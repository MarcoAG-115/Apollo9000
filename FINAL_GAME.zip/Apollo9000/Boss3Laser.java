import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Boss3Laser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boss3Laser extends Actor
{
    private boolean removed = false;
    GreenfootImage img = getImage();
    boolean check = true;
    /**
     * Act - do whatever the Boss3Laser wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        img.scale(300, 300);
        setLocation(getX(), getY()+1);
        
    }
    
    public boolean hitsRocket3(Rocket ship3)
    {
        return getObjectsInRange(getImage().getWidth()/2, 
            Rocket.class).contains(ship3);
    }
    
    
}
