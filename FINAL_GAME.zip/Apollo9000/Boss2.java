import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Boss2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boss2 extends Actor
{
    int healthB = 0;
    private int num = 1;
    boolean dead = false;
    GreenfootImage img = getImage();
    int cooldown = 0;
    /**
     * Act - do whatever the Boss2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        img.scale(300, 300);
        cooldown();
        boss2Movement();
        boss2Damage();
        if (dead == false)
        {
            verticalMove();
        }
       
    }
    
     public void verticalMove()
    {
            
          int block = getImage().getHeight()/2;
          if (getY() < block || getY() > getWorld().getHeight()-block)
          {
              num = -num;
          }
          setLocation(getX(), getY()+num*5);
    }
    
    public void shoot() {
        getWorld().addObject(new Boss2Laser(), getX(), getY());
    }
   
    public void cooldown() {
        if(cooldown == 0) {
            shoot();
        }
        if(cooldown == 0) {
            cooldown = 5;
        }
        if(cooldown > 0){
            cooldown--;
        }
    }
    public void boss2Movement() 
    {
        
        if (getX() == 500)
        {
            setLocation(getX(), getY());
        }
        else
        {
            setLocation(getX()-1, getY());
        }
        
       
    }
    public void boss2Damage() 
    {
        
        if (isTouching(Laser.class))
        {
            removeTouching(Laser.class);
            getWorld().addObject(new Explosion1(), getX(), getY());
            Greenfoot.playSound("explosion.wav");
            healthB = healthB + 1;
            if (healthB > 150) 
            {
                getWorld().removeObject(this);
                dead = true;
            }
        }
        
       
    }
}
