import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class Explosion1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Explosion1 extends Actor
{
    private final double SCALE_FACTOR = 1.25;
    private final int MAX_SIZE = 8;
    private int size;
    public Explosion1() {
        setImage(new GreenfootImage("explosion.png"));
        size = 1;
    }
    /**
     * Act - do whatever the Explosion1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        GreenfootImage img = getImage();
       int width = (int)(img.getWidth() * SCALE_FACTOR);
       int height = (int)(img.getHeight() * SCALE_FACTOR);
       img.scale(width, height);
       size = size + 1;
       if (size == MAX_SIZE) {
           getWorld().removeObject(this);
       }
    }
}
